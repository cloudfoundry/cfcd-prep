#!/bin/bash

printenv